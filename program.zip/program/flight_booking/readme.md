**Log on to codeastro.com for more projects!***

**Database Name: ofbsphp**

**Developed by Sujoy Dcunha, Christina Pereira, Mark Coutinho**

**Recommended PHP Version 5.6, 7.4**


**Admin Login Details**

Username: admin
Password: codeastro.com


# **Online Flight Booking Management System**

## Required PHP Version: >= 7.4

=================================================
**Originally Developed By:Sujoy Dcunha, Christina Pereira, Mark Coutinho**
**Downloaded @: codeastro.com**
=================================================
This is a modified copy. Some error occurred while running the project using PHP v8.1 and MariaDB 10.24.
Modifcations and changes are mostly done on the front-end side (UI/UX)
Backend Script Modification has been done also.


=================================================
## **Default Admin Access**
**username: admin**
**password: admin123**